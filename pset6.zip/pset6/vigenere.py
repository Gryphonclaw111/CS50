import cs50
import sys

def main():
    k = sys.argv[1]
    for x in k:
        if(x.isalpha):
            print("", end="")
        else:
            print("error")
            return 1
    p = cs50.get_string()
    z = 0
    for i in p:
        if(i.isalpha):
            j = z % len(k)
            z += 1
            if(k[j].isupper()):
                key = ord(k[j]) - 65
                if(i.isupper):
                    alpha = ord(i) - 65
                    c = (alpha + key) % 26
                    print(chr(c + 65), end="")
                elif(i.islower):
                    beta = ord(i) - 97
                    d = (beta + key) % 26
                    print(chr(d + 97), end="")
            elif(k[j].islower()):
                key = ord(k[j]) - 97
                if(i.isupper):
                    alpha = ord(i) - 65
                    c = (alpha + key) % 26
                    print(chr(c + 65), end="")
                elif(i.islower):
                    beta = ord(i) - 97
                    d = (beta + key) % 26
                    print(chr(d + 97), end="")
        else:
            print(i, end="")
if __name__ == "__main__":
    main()